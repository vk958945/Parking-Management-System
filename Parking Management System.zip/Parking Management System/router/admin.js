const router = require('express').Router()
const logindb = require('../model/logindb')
const vechiledb = require('../model/vechiledb')

function handlelogin(req, res, next) {
    if (req.session.isAuth) {
        next()
    } else {
        res.redirect('/admin')
    }
}

router.get('/', (req, res) => {
    res.render('admin/login.ejs')
})

router.post('/loginrecord', async (req, res) => {
    const { us, pass } = req.body
    const record = await logindb.findOne({ username: us })
    if (record !== null) {
        if (record.password == pass) {
            req.session.isAuth = true
            res.redirect('/admin/dashboard')
        } else {
            res.redirect('/admin')
        }
    } else {
        res.redirect('/admin')
    }

})

router.get('/logout', (req, res) => {
    req.session.destroy()
    res.redirect('/admin')
})

router.get('/dashboard', handlelogin, (req, res) => {
    res.render('admin/dashboard.ejs')
})

router.get('/parking', handlelogin, async(req, res) => {
    const record =await vechiledb.find()
    res.render('admin/parkingmgt.ejs',{record})
})

router.get('/vechileadd',handlelogin,(req,res)=>{
    res.render('admin/vechileadd.ejs')
})

router.post('/vechilerecord',async(req,res)=>{
    const{vno,vtype,vtime}=req.body
    const record = new vechiledb({vno:vno,vtype:vtype})
    await record.save()
    res.redirect('/admin/parking')
})


router.get('/outtimerecord/:id',async(req,res)=>{
    const id = req.params.id
    //const{vout}=req.body
    const vout = new Date()
    const record = await vechiledb.findById(id)
    const vtime = (vout-record.vintime)/(1000*60*60)
   
    let amount = 0
    if(record.vtype=='2W'){
    amount = Math.round(vtime*20)
    }else if(record.vtype=='3W'){
        amount = Math.round(vtime*30)
    }else if(record.vtype=='4W'){
        amount = Math.round(vtime*50)
    }else if(record.vtype=='LW'){
        amount = Math.round(vtime*100)
    }else if(record.vtype=='HW'){
        amount = Math.round(vtime*200)
    }    
      
    await vechiledb.findByIdAndUpdate(id,{vout:vout,amountcharge:amount,status:'OUT'})
    res.redirect('/admin/parking')

})

router.get('/printout/:id',handlelogin, async(req,res)=>{
    const id = req.params.id
   const record =  await vechiledb.findById(id)
   res.render('admin/printout.ejs',{record})
})

router.get('/delete/:id',async(req,res)=>{
    const id = req.params.id
    await vechiledb.findByIdAndDelete(id)
    res.redirect('/admin/parking')
})

module.exports = router