const express = require('express')
const app = express()
app.use(express.urlencoded({extends:false}))
const admin = require('./router/admin')
const frontend = require('./router/frontend')
const session = require('express-session')

const mongoose = require('mongoose')
const { urlencoded } = require('express')

mongoose.connect('mongodb://127.0.0.1:27017/parkingdatabase',()=>{
    console.log("Connected to Database parking database.")
})

app.use(session({
    secret:'vivek',
    resave:false,
    saveUninitialized:false
}))


app.use('/admin',admin)
app.use(frontend)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(5000, ()=>{
    console.log("Server is running on port 5000.")
})