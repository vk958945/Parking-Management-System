const mongoose = require('mongoose')

const vechileSchema = mongoose.Schema({
    vno:String,
    vtype:String,
    vintime:{type:Date,default:new Date()},
    status:{type:String,default:'IN'},
    vout:{type:Date,default:''},
    amountcharge:{type:Number,default:0}
})

module.exports=mongoose.model('vechile',vechileSchema)